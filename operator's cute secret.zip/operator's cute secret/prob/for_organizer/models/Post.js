const mongoose = require("mongoose");

const postSchema = new mongoose.Schema({
  title: String,
  content: String,
  file: String,
  fileType: String,
  author: String,
  isSecret: { type: Boolean, default: false },
  password: String,
});

module.exports = mongoose.model("Post", postSchema);
