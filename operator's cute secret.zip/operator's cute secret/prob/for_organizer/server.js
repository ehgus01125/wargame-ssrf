const express = require("express");
const session = require("express-session");
const mongoose = require("mongoose");
const path = require("path");
const bodyParser = require("body-parser");
const dotenv = require("dotenv");
const multer = require("multer");
const fs = require("fs");
const sanitizeHtml = require("sanitize-html");
const { exec } = require("child_process");

dotenv.config();

mongoose.set("strictQuery", false);

const app = express();
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views")); // views 폴더 설정
app.use(express.static("views"));

// ✅ 세션 설정
app.use(session({
  secret: "super_secret_k ey",
  resave: false,
  saveUninitialized: true,
  cookie: { secure: false }
}));

// ✅ MongoDB 연결
mongoose.connect(process.env.MONGO_URL || "mongodb://localhost:27017/vulnerableBlog", {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

const User = mongoose.models.User || mongoose.model("User", new mongoose.Schema({
  uid: String,
  upw: String,
  admin: Boolean
}));

const Post = mongoose.models.Post || mongoose.model("Post", new mongoose.Schema({
  title: String,
  content: String,
  author: String,
  isSecret: Boolean,
  password: String,
  image: String
}));

// ✅ 이미지 저장 설정 (multer)
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadPath = path.join(__dirname, "uploads");
    if (!fs.existsSync(uploadPath)) fs.mkdirSync(uploadPath, { recursive: true });
    cb(null, uploadPath);
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname));
  }
});

const upload = multer({ storage });

// ✅ 메인 페이지
app.get("/", async (req, res) => {
  const posts = await Post.find();
  console.log("🔍 게시물 목록:", posts); // 서버 콘솔에서 데이터 확인
  res.render("index", { user: req.session.user, posts });
});

// ✅ 로그인 페이지
app.get("/login", (req, res) => {
  res.render(path.join(__dirname, "views/login.ejs"));
});

// ✅ 로그인 처리 (NoSQL Injection 가능)
app.post("/login", async (req, res) => {
  console.log("🔍 Received Body:", req.body);
  const { username, password } = req.body;

  try {
    const user = await User.findOne({ uid: username, upw: password });

    if (user) {
      req.session.user = { username: user.uid, isAdmin: user.admin };
      return res.redirect("/");
    }
    res.status(401).send("<h1>로그인 실패</h1>");
  } catch (err) {
    console.error("🚨 서버 오류 발생:", err);
    res.status(500).send("서버 오류");
  }
});

// ✅ 관리자만 `/upload` 접근 가능
app.get("/upload", (req, res) => {
  if (!req.session.user || !req.session.user.isAdmin) {
    return res.status(403).send("<h1>접근 금지: 관리자만 업로드 가능합니다.</h1>");
  }
  res.render(path.join(__dirname, "views/upload.ejs"));
});

// ✅ 게시물 업로드 (관리자만 가능, XSS 방지 적용)
app.post("/upload", upload.single("file"), async (req, res) => {
  if (!req.session.user || !req.session.user.isAdmin) {
    return res.status(403).send("<h1>접근 금지: 관리자만 업로드 가능합니다.</h1>");
  }

  const cleanContent = sanitizeHtml(req.body.content, { allowedTags: [], allowedAttributes: {} });

  let base64File = "";
  let filePath = "";

  // ✅ 업로드된 파일이 있을 경우
  if (req.file) {
      filePath = path.join(__dirname, "uploads", req.file.filename);
      const fileExt = path.extname(req.file.filename).substring(1);

      // ✅ PHP 파일이면 실행 가능하도록 처리 (실제 실행은 /uploads/:filename에서 처리)
      if (fileExt === "php") {
          console.log("🚀 PHP 파일 업로드:", filePath);
          base64File = `/uploads/${req.file.filename}`;
      } else {
          // ✅ 일반 파일(Base64 변환)
          try {
              const fileData = fs.readFileSync(filePath);
              base64File = `data:image/${fileExt};base64,${fileData.toString("base64")}`;
          } catch (err) {
              console.error("🚨 파일 읽기 오류:", err);
          }
      }
  }  
  await Post.create({
    title: req.body.title,
    content: cleanContent,
    author: req.session.user.username,
    isSecret: req.body.isSecret === "on",
    password: req.body.password || "",
    image: req.file ? req.file.filename : null
  });

  res.redirect("/");
});

// ✅ 일반 게시물 조회 (GET 방식)
app.get("/read/:id", async (req, res) => {
  try {
      if (!mongoose.Types.ObjectId.isValid(req.params.id)) {
          return res.status(400).send("<h1>잘못된 요청입니다.</h1>");
      }

      const post = await Post.findById(req.params.id);
      if (!post) {
          return res.status(404).send("<h1>게시물을 찾을 수 없습니다.</h1>");
      }
      // ✅ 비밀 게시물일 경우, 비밀번호 입력 페이지로 이동
      if (post.isSecret) {
          return res.render("secret", { postId: post.id });
      }
      console.log("🚀 게시물 로딩:", post.image);
      // ✅ 일반 게시물은 바로 렌더링
      return res.render("post", { post });
  } catch (err) {
      console.error("🚨 게시물 조회 오류:", err);
      res.status(500).send("서버 오류");
  }
});


// ✅ 게시물 비밀번호 검증 API (AJAX 사용)
app.post("/read/:id/check-password", async (req, res) => {
    const post = await Post.findById(req.params.id);
    if (!post) return res.status(404).json({ success: false, message: "게시물을 찾을 수 없습니다." });

    if (post.password === req.body.password) {
        let base64File = "";
        
        // ✅ 파일이 존재하는 경우, Base64 변환
        if (post.image) {
            const filePath = path.join(__dirname, "uploads", post.image);
            try {
                const fileData = fs.readFileSync(filePath);
                base64File = `data:image/png;base64,${fileData.toString("base64")}`;
            } catch (err) {
                console.error("🚨 파일 읽기 오류:", err);
            }
        }

        return res.json({ success: true, content: post.content, file: post.image ? `/uploads/${post.image}` : "" });
    } else {
        return res.status(401).json({ success: false, message: "비밀번호가 틀렸습니다." });
    }
});

// ✅ 로그아웃
app.get("/logout", (req, res) => {
  req.session.destroy(() => {
    res.redirect("/");
  });
});

// ✅ 업로드된 파일 제공 (PHP 실행 포함, Base64 변환)
app.get("/uploads/:filename", (req, res) => {
  const filePath = path.join(__dirname, "uploads", req.params.filename);
  const fileExt = path.extname(req.params.filename).substring(1);
  console.log(`파일 실행: ${filePath}`);
  if (filePath.endsWith(".php")) {
      console.log(`🚀 PHP 실행 시도: ${filePath}`);

      // ✅ PHP 실행 시도 확인을 위해 파일 존재 여부 체크
      if (!fs.existsSync(filePath)) {
          console.error("🚨 PHP 파일 없음:", filePath);
          return res.status(404).send("파일을 찾을 수 없습니다.");
      }
      exec(`php ${filePath}`, (error, stdout, stderr) => {
          if (error) {
              console.error("🚨 PHP 실행 오류:", stderr);
              return res.status(500).json({ success: false, message: `PHP 실행 오류: ${stderr}` });
          }
          
          if (!stdout.trim()) {
              console.error("🚨 PHP 실행 결과가 비어 있음!");
              return res.status(500).send("PHP 실행 결과가 없습니다.");
          }

          console.log("✅ PHP 실행 결과:", stdout);
          const base64Output = Buffer.from(stdout, "utf8").toString("base64");
          
          return res.json({ success: true, content: `data:image/png;base64,${base64Output}` });
      });
  } else {
      fs.readFile(filePath, (err, data) => {
          if (err) {
              console.error("🚨 파일 읽기 오류:", err);
              return res.status(500).json({ success: false, message: "파일을 읽을 수 없습니다." });
          }

          const base64File = `data:image/${fileExt};base64,${data.toString("base64")}`;
          console.log("✅ 파일 Base64 데이터:", base64File.substring(0, 50) + "..."); // 🚀 Base64 데이터 확인
          res.json({ success: true, content: base64File });
      });
  }
});


// ✅ 서버 실행
app.listen(3000, "0.0.0.0", () => console.log("✅ 서버 실행 중: http://0.0.0.0:3000"));
