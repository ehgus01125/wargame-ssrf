const fs = require("fs");
const path = require("path");

db = db.getSiblingDB("vulnerableBlog");

// ✅ 다양한 기본 계정 추가
db.users.insertMany([
  { uid: "admin", upw: process.env.ADMIN_PASSWORD || "defaultAdminPass", admin: 1 },
  { uid: "guest", upw: "guest1234", admin: 0 },
  { uid: "DogLover", upw: "RG9ncyBTYXZlIHRoZSBXb3JsZCE=", admin: 0 },
  { uid: "CatLover", upw: "Q2F0cyBTYXZlIHRoZSBXb3JsZCE=", admin: 0 }
]);

// ✅ 기본 게시물 등록 (글 + 이미지 포함, 비밀글 추가)
const uploadsPath = "app/uploads";
const defaultPosts = [
  { title: "공지!", filename: null, content: "반려동물들 혹은 귀여운 동물들을 공유하기 위한 블로그입니다! \n본인이 갖고 계신 모든 귀여운 동물 사진으로 우리들에게 심장 어택을 해주세요! \n[주의] 이상한 광고 및 무서운 사진은 밴 사유가 될 수 있음.", isSecret: false, password: null, author: "admin" },
  { title: "고양이 겁나 귀엽지 않음?", filename: "cats-8096304_640.jpg", content: "아 귀여워...", isSecret: false, password: null, author: "DogLover" },
  { title: "ㄴㄴ 개가 더 귀여움", filename: "puppy-5124947_640.jpg", content: "진짜 귀엽다 ㅠ", isSecret: false, password: null, author: "CatLover" },
  { title: "비밀", filename: null, content: "Flag: GH{D0gs_n_Cats_Sav_th2_Wor1d!}", isSecret: true, password: "ZG9nYW5kY2F0", author: "admin" }
];

const posts = [];
defaultPosts.forEach(post => {
  let base64Image = null;
  let imageType = null;

  if (post.filename) {
    const filePath = path.join( uploadsPath, post.filename);
    if (fs.existsSync(filePath)) {
      const fileData = fs.readFileSync(filePath);
      base64Image = fileData.toString("base64");

      console.log(`🚀 Base64 변환 성공 (${post.filename}): ${base64Image.length} bytes`);
      
       // ✅ 파일 타입 자동 감지 (JPG, PNG 지원)
       if (post.filename.endsWith(".jpg") || post.filename.endsWith(".jpeg")) {
        imageType = "image/jpeg";
      } else if (post.filename.endsWith(".png")) {
        imageType = "image/png";
      } else {
        imageType = "application/octet-stream"; // 기본값
      }
    } else {
      console.error(`🚨 파일이 존재하지 않음: ${filePath}`);
    }
  }

  posts.push({
    title: post.title,
    content: post.content,
    image: post.filename,
    imageType: imageType,
    author: post.author,
    isSecret: post.isSecret,  // ✅ 비밀글 여부 적용
    password: post.password    // ✅ 비밀번호 설정 (비밀글일 경우)
  });
});

if (posts.length > 0) {
  db.posts.insertMany(posts);
}