const express = require("express");
const session = require("express-session");
const mongoose = require("mongoose");
const path = require("path");
const bodyParser = require("body-parser");
const dotenv = require("dotenv");
const multer = require("multer");
const fs = require("fs");
const sanitizeHtml = require("sanitize-html");
const { exec } = require("child_process");

dotenv.config();

mongoose.set("strictQuery", false);

const app = express();
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));
app.use(express.static("views"));

app.use(session({
  secret: "super_secret_k ey",
  resave: false,
  saveUninitialized: true,
  cookie: { secure: false }
}));

mongoose.connect(process.env.MONGO_URL || "mongodb://localhost:27017/vulnerableBlog", {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

const User = mongoose.models.User || mongoose.model("User", new mongoose.Schema({
  uid: String,
  upw: String,
  admin: Boolean
}));

const Post = mongoose.models.Post || mongoose.model("Post", new mongoose.Schema({
  title: String,
  content: String,
  author: String,
  isSecret: Boolean,
  password: String,
  image: String
}));

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadPath = path.join(__dirname, "uploads");
    if (!fs.existsSync(uploadPath)) fs.mkdirSync(uploadPath, { recursive: true });
    cb(null, uploadPath);
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname));
  }
});

const upload = multer({ storage });

app.get("/", async (req, res) => {
  const posts = await Post.find();
  console.log("🔍 게시물 목록:", posts);
  res.render("index", { user: req.session.user, posts });
});

app.get("/login", (req, res) => {
  res.render(path.join(__dirname, "views/login.ejs"));
});

app.post("/login", async (req, res) => {
  console.log("🔍 Received Body:", req.body);
  const { username, password } = req.body;

  try {
    const user = await User.findOne({ uid: username, upw: password });

    if (user) {
      req.session.user = { username: user.uid, isAdmin: user.admin };
      return res.redirect("/");
    }
    res.status(401).send("<h1>로그인 실패</h1>");
  } catch (err) {
    console.error("🚨 서버 오류 발생:", err);
    res.status(500).send("서버 오류");
  }
});

app.get("/upload", (req, res) => {
  if (!req.session.user || !req.session.user.isAdmin) {
    return res.status(403).send("<h1>접근 금지: 관리자만 업로드 가능합니다.</h1>");
  }
  res.render(path.join(__dirname, "views/upload.ejs"));
});

app.post("/upload", upload.single("file"), async (req, res) => {
  if (!req.session.user || !req.session.user.isAdmin) {
    return res.status(403).send("<h1>접근 금지: 관리자만 업로드 가능합니다.</h1>");
  }

  const cleanContent = sanitizeHtml(req.body.content, { allowedTags: [], allowedAttributes: {} });

  let base64File = "";
  let filePath = "";

  if (req.file) {
      filePath = path.join(__dirname, "uploads", req.file.filename);
      const fileExt = path.extname(req.file.filename).substring(1);

      if (fileExt === "php") {
          console.log(filePath);
          base64File = `/uploads/${req.file.filename}`;
      } else {
          try {
              const fileData = fs.readFileSync(filePath);
              base64File = `data:image/${fileExt};base64,${fileData.toString("base64")}`;
          } catch (err) {
              console.error("🚨 파일 읽기 오류:", err);
          }
      }
  }  
  await Post.create({
    title: req.body.title,
    content: cleanContent,
    author: req.session.user.username,
    isSecret: req.body.isSecret === "on",
    password: req.body.password || "",
    image: req.file ? req.file.filename : null
  });

  res.redirect("/");
});
app.get("/read/:id", async (req, res) => {
  try {
      if (!mongoose.Types.ObjectId.isValid(req.params.id)) {
          return res.status(400).send("<h1>잘못된 요청입니다.</h1>");
      }

      const post = await Post.findById(req.params.id);
      if (!post) {
          return res.status(404).send("<h1>게시물을 찾을 수 없습니다.</h1>");
      }
      if (post.isSecret) {
          return res.render("secret", { postId: post.id });
      }
      console.log("🚀 게시물 로딩:", post.image);
      return res.render("post", { post });
  } catch (err) {
      console.error("🚨 게시물 조회 오류:", err);
      res.status(500).send("서버 오류");
  }
});


app.post("/read/:id/check-password", async (req, res) => {
    const post = await Post.findById(req.params.id);
    if (!post) return res.status(404).json({ success: false, message: "게시물을 찾을 수 없습니다." });

    if (post.password === req.body.password) {
        let base64File = "";
        
        if (post.image) {
            const filePath = path.join(__dirname, "uploads", post.image);
            try {
                const fileData = fs.readFileSync(filePath);
                base64File = `data:image/png;base64,${fileData.toString("base64")}`;
            } catch (err) {
                console.error("🚨 파일 읽기 오류:", err);
            }
        }

        return res.json({ success: true, content: post.content, file: post.image ? `/uploads/${post.image}` : "" });
    } else {
        return res.status(401).json({ success: false, message: "비밀번호가 틀렸습니다." });
    }
});

app.get("/logout", (req, res) => {
  req.session.destroy(() => {
    res.redirect("/");
  });
});

app.get("/uploads/:filename", (req, res) => {
  const filePath = path.join(__dirname, "uploads", req.params.filename);
  const fileExt = path.extname(req.params.filename).substring(1);
  console.log(`파일 실행: ${filePath}`);
  if (filePath.endsWith(".php")) {
      if (!fs.existsSync(filePath)) {
          console.error(filePath);
          return res.status(404).send("파일을 찾을 수 없습니다.");
      }
      exec(`php ${filePath}`, (error, stdout, stderr) => {
          if (error) {
              console.error(stderr);
              return res.status(500).json({ success: false, message: `${stderr}` });
          }
          
          if (!stdout.trim()) {
              console.error();
              return res.status(500).send();
          }

          console.log(stdout);
          const base64Output = Buffer.from(stdout, "utf8").toString("base64");
          
          return res.json({ success: true, content: `data:image/png;base64,${base64Output}` });
      });
  } else {
      fs.readFile(filePath, (err, data) => {
          if (err) {
              console.error(err);
              return res.status(500).json({ success: false, message: "파일을 읽을 수 없습니다." });
          }

          const base64File = `data:image/${fileExt};base64,${data.toString("base64")}`;
          console.log(base64File.substring(0, 50));
          res.json({ success: true, content: base64File });
      });
  }
});


app.listen(3000, "0.0.0.0", () => console.log("✅ 서버 실행 중: http://0.0.0.0:3000"));
