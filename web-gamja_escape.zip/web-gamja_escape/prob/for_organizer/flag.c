#include <stdio.h>

int main(void) {

printf("GH{RUn_F4st_B3f0r3_Th3y_C4tch_U}");

return 0;
}